<?php
namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Centralizes the field-allowlist and post-validation checks every route
 * uses — one gate, not re-implemented per handler. Fully independent of
 * the separate, unrelated Odito Lead Capture plugin (different trust
 * boundary, no shared code, never modified by this one).
 */
class Security {

	/**
	 * The ONLY fields this Bridge will ever read or write. Matches exactly
	 * the fields the Odito backend's own Task verification system can
	 * confirm (see issueSnapshotTypes.js): title, meta_description,
	 * canonical, robots. Never expand this from client input — only from a
	 * reviewed code change here.
	 */
	const SUPPORTED_FIELDS = array( 'title', 'meta_description', 'canonical', 'robots' );

	/**
	 * The only 4 robots wire values this Bridge will ever accept — must stay
	 * in exact lockstep with the Odito backend's own valueNormalization.js
	 * robotsValueToWireString(), which alphabetically sorts the restrictive
	 * directives it includes ("nofollow" sorts before "noindex") — this is
	 * NOT "noindex, nofollow". Only the RESTRICTIVE directives are ever
	 * meaningful here; "" means no restriction (index, follow).
	 */
	const VALID_ROBOTS_WIRE_VALUES = array( '', 'noindex', 'nofollow', 'nofollow, noindex' );

	/**
	 * Site-level (not per-post) schema entities and their allowed fields —
	 * confirmed against Rank Math's own real source (its
	 * rank-math/set-website-identity and rank-math/set-breadcrumb-settings
	 * abilities): Organization/Knowledge Graph fields live in the
	 * `rank-math-options-titles` option, breadcrumbs in
	 * `rank-math-options-general`. Never expand this from client input —
	 * only from a reviewed code change here, same as SUPPORTED_FIELDS.
	 */
	const SITE_SCHEMA_ENTITIES = array(
		'organization' => array( 'name', 'description', 'url', 'logo', 'sameAs' ),
		'breadcrumbs'  => array( 'enabled' ),
	);

	/** True if the CURRENT authenticated user may edit this specific post. */
	public static function current_user_can_edit_post( int $post_id ): bool {
		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Site-level schema/settings changes affect every page on the site, not
	 * one post — gated behind manage_options (Administrator-level) rather
	 * than edit_post, regardless of which custom capability a given Rank
	 * Math version registers for its own settings pages (rank_math_titles/
	 * rank_math_general aren't guaranteed present on every install).
	 */
	public static function current_user_can_manage_site_seo(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function is_supported_site_field( string $entity, string $field ): bool {
		return isset( self::SITE_SCHEMA_ENTITIES[ $entity ] ) && in_array( $field, self::SITE_SCHEMA_ENTITIES[ $entity ], true );
	}

	/** @return \WP_Post|null null if the post doesn't exist or isn't a supported public post type. */
	public static function validate_post( int $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return null;
		}
		$post_type_object = get_post_type_object( $post->post_type );
		if ( ! $post_type_object || ! $post_type_object->public ) {
			return null;
		}
		return $post;
	}

	public static function is_supported_field( string $field ): bool {
		return in_array( $field, self::SUPPORTED_FIELDS, true );
	}

	/**
	 * Defense-in-depth value validation, applied server-side regardless of
	 * what the Node backend already checked before sending this request —
	 * the Bridge must never trust a value's shape purely because it arrived
	 * over an authenticated connection. title/meta_description have no
	 * format constraint beyond length (already checked by the caller); only
	 * canonical and robots have a real closed shape to enforce here.
	 *
	 * @return true|string true if valid, otherwise a human-readable reason.
	 */
	public static function validate_field_value( string $field, string $value ) {
		if ( 'canonical' === $field ) {
			return self::is_valid_canonical_url( $value )
				? true
				: 'Canonical must be a plain absolute http(s) URL, never HTML markup, a relative path, or a javascript:/data: URL.';
		}
		if ( 'robots' === $field ) {
			return in_array( $value, self::VALID_ROBOTS_WIRE_VALUES, true )
				? true
				: 'Robots value must be one of: "", "noindex", "nofollow", "nofollow, noindex".';
		}
		return true;
	}

	/**
	 * Value validation for a site-level schema field. Same shape as
	 * validate_field_value() above but keyed by (entity, field) instead of a
	 * single field name, since 'name'/'description' mean something different
	 * per entity and only 'organization' has URL-shaped fields at all.
	 *
	 * @return true|string true if valid, otherwise a human-readable reason.
	 */
	public static function validate_site_field_value( string $entity, string $field, string $value ) {
		if ( 'organization' === $entity && in_array( $field, array( 'url', 'logo', 'sameAs' ), true ) ) {
			return self::is_valid_canonical_url( $value )
				? true
				: 'This field must be a plain absolute http(s) URL, never HTML markup or a javascript:/data: URL.';
		}
		if ( 'organization' === $entity && in_array( $field, array( 'name', 'description' ), true ) ) {
			if ( '' === $value || false !== strpos( $value, '<' ) || false !== strpos( $value, '>' ) ) {
				return 'This field must be non-empty plain text, never HTML markup.';
			}
			return true;
		}
		if ( 'breadcrumbs' === $entity && 'enabled' === $field ) {
			return true; // Boolean — validated by is_bool() at the request-parsing layer, not here.
		}
		return true;
	}

	/**
	 * Mirrors the shape of Odito's own extractCanonicalUrlValue() validation
	 * (absolute http/https only, no markup) — deliberately NOT the unwrapping
	 * half of that function (this layer never salvages a malformed value, it
	 * only rejects one that shouldn't have arrived here at all).
	 */
	public static function is_valid_canonical_url( string $value ): bool {
		// str_contains() is PHP 8.0+ only — this plugin declares PHP 7.4 as
		// its minimum supported version (see odito-seo-bridge.php), so
		// strpos() is used here instead, same as the rest of this codebase.
		if ( '' === $value || false !== strpos( $value, '<' ) || false !== strpos( $value, '>' ) ) {
			return false;
		}
		// Whitespace and control characters (a line break would inject an extra
		// entry into Rank Math's newline-delimited social_additional_profiles
		// option), quotes, backslashes and backticks are never part of a URL
		// this plugin should store.
		if ( preg_match( '/[\s\x00-\x1f\x7f"\\\\`]/', $value ) ) {
			return false;
		}
		$parts = wp_parse_url( $value );
		if ( ! $parts || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}
		return in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true );
	}
}
