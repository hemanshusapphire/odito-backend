<?php
namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AggregateRating structured data for a single post, applied on Odito's behalf.
 *
 * Odito only ever sends a rating for an entity that ALREADY exists in the page's
 * own schema (Product, Service, LocalBusiness, Organization ...), identified by
 * its @id. This class attaches that rating to the entity — it never creates an
 * unrelated new one:
 *
 *   1. Where the active SEO plugin exposes its schema graph (Rank Math's
 *      `rank_math/json_ld`, Yoast's `wpseo_schema_graph`), the rating is merged
 *      straight into the entity that has the matching @id, inside that plugin's
 *      own JSON-LD.
 *   2. Otherwise (no such plugin, or no matching entity in its graph) the rating
 *      is printed as a JSON-LD node carrying that same @id, name and @type, so it
 *      still refers to the same entity rather than defining a new one.
 *
 * Like Faq_Schema, what is stored is not the request payload but the validated
 * target + rating extracted from it, in one post-meta key this plugin owns;
 * everything that is rendered or returned is rebuilt from that. Validation is
 * strict and all-or-nothing.
 */
class Rating_Schema {

	/** The only post-meta key this feature writes. */
	const META_KEY = '_odito_aggregate_rating';

	const MAX_NAME_LENGTH = 500;
	const MAX_ID_LENGTH   = 2000;
	const MAX_COUNT       = 1000000000;

	/** True once a plugin filter merged the rating into its own graph during this request. */
	private static $merged = false;

	public static function init() {
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'merge_into_graph_keyed' ), 99, 2 );
		add_filter( 'wpseo_schema_graph', array( __CLASS__, 'merge_into_graph_list' ), 99, 2 );
		// After both plugins have printed (Rank Math wp_head@90, Yoast wp_head@1): only fills the gap.
		add_action( 'wp_head', array( __CLASS__, 'render_fallback' ), 100 );
	}

	/**
	 * Validates a rating JSON-LD node.
	 *
	 * @param mixed $schema Decoded JSON (array) as received from the REST request.
	 * @return array|null array{target:array{type:string|string[],id:string,name:string},rating:array<string,string>} or null when invalid.
	 */
	public static function validate( $schema ) {
		if ( ! is_array( $schema ) ) {
			return null;
		}

		$type = isset( $schema['@type'] ) ? $schema['@type'] : null;
		if ( ! self::valid_type( $type ) ) {
			return null;
		}

		$id = isset( $schema['@id'] ) ? $schema['@id'] : null;
		if ( ! is_string( $id ) || strlen( $id ) > self::MAX_ID_LENGTH || preg_match( '/[\s<>"\']/', $id ) ) {
			return null;
		}
		$parts = wp_parse_url( $id );
		if ( ! $parts || empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return null;
		}

		$name = isset( $schema['name'] ) && is_string( $schema['name'] ) ? self::clean_text( $schema['name'] ) : '';
		if ( '' === $name || mb_strlen( $name, 'UTF-8' ) > self::MAX_NAME_LENGTH ) {
			return null;
		}

		$ar = isset( $schema['aggregateRating'] ) ? $schema['aggregateRating'] : null;
		if ( ! is_array( $ar ) || ! isset( $ar['@type'] ) || 'AggregateRating' !== $ar['@type'] ) {
			return null;
		}

		$value = self::number( isset( $ar['ratingValue'] ) ? $ar['ratingValue'] : null );
		$best  = isset( $ar['bestRating'] ) ? self::number( $ar['bestRating'] ) : '5';
		$worst = isset( $ar['worstRating'] ) ? self::number( $ar['worstRating'] ) : null;
		if ( null === $value || null === $best || ( isset( $ar['worstRating'] ) && null === $worst ) ) {
			return null;
		}
		if ( (float) $value <= 0 || (float) $best <= 0 || (float) $value > (float) $best ) {
			return null;
		}
		if ( null !== $worst && ( (float) $worst >= (float) $best || (float) $value < (float) $worst ) ) {
			return null;
		}

		$rating = array(
			'ratingValue' => $value,
			'bestRating'  => $best,
		);
		if ( null !== $worst ) {
			$rating['worstRating'] = $worst;
		}
		$have_count = false;
		foreach ( array( 'reviewCount', 'ratingCount' ) as $count_key ) {
			if ( isset( $ar[ $count_key ] ) ) {
				$count = self::count( $ar[ $count_key ] );
				if ( null === $count ) {
					return null;
				}
				$rating[ $count_key ] = $count;
				$have_count           = true;
			}
		}
		if ( ! $have_count ) {
			return null;
		}

		return array(
			'target' => array(
				'type' => $type,
				'id'   => $id,
				'name' => $name,
			),
			'rating' => $rating,
		);
	}

	private static function valid_type( $type ) {
		$ok = function ( $t ) {
			return is_string( $t ) && 1 === preg_match( '/^[A-Za-z][A-Za-z0-9]{0,63}$/', $t );
		};
		if ( is_array( $type ) ) {
			if ( empty( $type ) || count( $type ) > 8 ) {
				return false;
			}
			foreach ( $type as $t ) {
				if ( ! $ok( $t ) ) {
					return false;
				}
			}
			return true;
		}
		return $ok( $type );
	}

	/** Whitespace-collapse only — the entity name is copied verbatim from the page's own schema. */
	private static function clean_text( $value ) {
		$value = wp_check_invalid_utf8( (string) $value, true );
		$value = preg_replace( '/\s+/u', ' ', $value );
		return trim( (string) $value );
	}

	/** A plain non-negative decimal (number or numeric string) as a normalized string, else null. */
	private static function number( $value ) {
		if ( is_int( $value ) || is_float( $value ) ) {
			$value = (string) $value;
		}
		if ( ! is_string( $value ) || 1 !== preg_match( '/^\d{1,9}(\.\d{1,4})?$/', trim( $value ) ) ) {
			return null;
		}
		return trim( $value );
	}

	/** A positive integer count (number or digit string) as a string, else null. */
	private static function count( $value ) {
		if ( is_int( $value ) ) {
			$value = (string) $value;
		}
		if ( ! is_string( $value ) || 1 !== preg_match( '/^\d{1,10}$/', trim( $value ) ) ) {
			return null;
		}
		$n = (int) trim( $value );
		return ( $n >= 1 && $n <= self::MAX_COUNT ) ? (string) $n : null;
	}

	/** Builds the AggregateRating object. */
	private static function rating_object( array $rating ): array {
		$out = array( '@type' => 'AggregateRating' );
		foreach ( array( 'ratingValue', 'reviewCount', 'ratingCount', 'bestRating', 'worstRating' ) as $key ) {
			if ( isset( $rating[ $key ] ) ) {
				$out[ $key ] = (string) $rating[ $key ];
			}
		}
		return $out;
	}

	/** @return array|null Stored {target, rating}, re-validated on read so corrupt meta is never rendered. */
	public static function get( int $post_id ) {
		$raw = get_post_meta( $post_id, self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return null;
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) || ! isset( $decoded['target'], $decoded['rating'] ) || ! is_array( $decoded['target'] ) || ! is_array( $decoded['rating'] )
			|| ! isset( $decoded['target']['type'], $decoded['target']['id'], $decoded['target']['name'] ) ) {
			return null;
		}
		return self::validate( self::build_node( $decoded ) );
	}

	/** Stores a value that already passed validate(). */
	public static function save( int $post_id, array $stored ) {
		update_post_meta( $post_id, self::META_KEY, wp_slash( wp_json_encode( $stored, JSON_UNESCAPED_UNICODE ) ) );
	}

	/** The full JSON-LD node (entity @id/@type/name + aggregateRating), rebuilt from stored data only. */
	public static function build_node( array $stored ): array {
		return array(
			'@context'        => 'https://schema.org',
			'@type'           => $stored['target']['type'],
			'@id'             => $stored['target']['id'],
			'name'            => $stored['target']['name'],
			'aggregateRating' => self::rating_object( $stored['rating'] ),
		);
	}

	private static function current_stored() {
		if ( ! is_singular() ) {
			return null;
		}
		$post = get_queried_object();
		if ( ! $post || empty( $post->ID ) ) {
			return null;
		}
		/** This filter lets a site opt a post out (e.g. another plugin already prints this rating). */
		if ( ! apply_filters( 'odito_seo_bridge_render_rating_schema', true, $post ) ) {
			return null;
		}
		return self::get( (int) $post->ID );
	}

	/** Adds the rating to the entity with the matching @id in a list of graph pieces. */
	private static function merge_into_list( array $pieces, array $stored ): array {
		foreach ( $pieces as $index => $piece ) {
			if ( is_array( $piece ) && isset( $piece['@id'] ) && $piece['@id'] === $stored['target']['id'] ) {
				$pieces[ $index ]['aggregateRating'] = self::rating_object( $stored['rating'] );
				self::$merged                        = true;
			}
		}
		return $pieces;
	}

	/** Rank Math: `rank_math/json_ld` — an array of entities keyed by name, each with its own @id. */
	public static function merge_into_graph_keyed( $data, $jsonld = null ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$stored = self::current_stored();
		return $stored ? self::merge_into_list( $data, $stored ) : $data;
	}

	/** Yoast SEO: `wpseo_schema_graph` — a list of graph pieces. */
	public static function merge_into_graph_list( $graph, $context = null ) {
		if ( ! is_array( $graph ) ) {
			return $graph;
		}
		$stored = self::current_stored();
		return $stored ? self::merge_into_list( $graph, $stored ) : $graph;
	}

	/** wp_head: prints the same-@id node only when no SEO plugin merged the rating into its own graph. */
	public static function render_fallback() {
		if ( self::$merged ) {
			return;
		}
		$stored = self::current_stored();
		if ( ! $stored ) {
			return;
		}
		// JSON_HEX_TAG/AMP: "<", ">" and "&" are escaped, so text can never close the <script> element.
		$json = wp_json_encode( self::build_node( $stored ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
		if ( ! is_string( $json ) || '' === $json ) {
			return;
		}
		echo "\n<script type=\"application/ld+json\" class=\"odito-rating-schema\">" . $json . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with HEX_TAG/HEX_AMP above.
	}
}
