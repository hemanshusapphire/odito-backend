<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Yoast SEO's own REST field (`yoast_head_json`) is deliberately read-only
 * by design (documented by Yoast itself) — Odito's existing external REST
 * adapter is read-only for exactly this reason. Yoast stores its
 * title/description/canonical as standard post meta under well-documented
 * keys it intentionally does not register for REST. Direct
 * update_post_meta()/get_post_meta() from within this plugin is the
 * correct, documented way to reach them.
 */
class YoastProvider implements ProviderInterface {

	const META_TITLE       = '_yoast_wpseo_title';
	const META_DESCRIPTION = '_yoast_wpseo_metadesc';
	const META_CANONICAL   = '_yoast_wpseo_canonical';

	public static function get_key(): string {
		return 'yoast';
	}

	public static function is_active(): bool {
		return defined( 'WPSEO_VERSION' ) || class_exists( '\\WPSEO_Options' );
	}

	public function get_capabilities(): array {
		return array(
			'title'            => array(
				'read'  => true,
				'write' => true,
			),
			'meta_description' => array(
				'read'  => true,
				'write' => true,
			),
			'canonical'        => array(
				'read'  => true,
				'write' => true,
			),
		);
	}

	public function get_seo_data( int $post_id ): array {
		return array(
			'title'            => $this->read_meta( $post_id, self::META_TITLE ),
			'meta_description' => $this->read_meta( $post_id, self::META_DESCRIPTION ),
			'canonical'        => $this->read_meta( $post_id, self::META_CANONICAL ),
		);
	}

	public function update_seo_field( int $post_id, string $field, string $value ): bool {
		$map = array(
			'title'            => self::META_TITLE,
			'meta_description' => self::META_DESCRIPTION,
			'canonical'        => self::META_CANONICAL,
		);
		if ( ! isset( $map[ $field ] ) ) {
			throw new \Exception( 'Unsupported field for Yoast: ' . $field );
		}
		return false !== update_post_meta( $post_id, $map[ $field ], $value );
	}

	private function read_meta( int $post_id, string $key ): ?string {
		$value = get_post_meta( $post_id, $key, true );
		return ( is_string( $value ) && '' !== $value ) ? $value : null;
	}
}
