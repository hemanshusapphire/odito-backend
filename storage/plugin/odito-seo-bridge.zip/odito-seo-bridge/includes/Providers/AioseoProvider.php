<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AIOSEO stores its metadata in its own custom table, but officially
 * registers a REST field (`aioseo_meta_data`) on the core
 * `/wp/v2/{post_type}/{id}` route — the exact same field Odito's existing
 * external REST adapter already writes through successfully. Rather than
 * reach into AIOSEO's internal classes/table structure, this provider
 * reuses that SAME officially-registered field via WordPress's own
 * internal REST dispatch (rest_do_request()): the identical code path an
 * external REST client uses, just invoked in-process. This is safer than
 * guessing at AIOSEO internals and stays correct across AIOSEO versions
 * that keep the field contract stable.
 */
class AioseoProvider implements ProviderInterface {

	public static function get_key(): string {
		return 'aioseo';
	}

	public static function is_active(): bool {
		return defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' );
	}

	public function get_capabilities(): array {
		return array(
			'title'            => array(
				'read'  => true,
				'write' => true,
			),
			'meta_description' => array(
				'read'  => true,
				'write' => true,
			),
			'canonical'        => array(
				'read'  => true,
				'write' => true,
			),
		);
	}

	public function get_seo_data( int $post_id ): array {
		$meta = $this->read_meta_data( $post_id );
		return array(
			'title'            => $meta['title'] ?? null,
			'meta_description' => $meta['description'] ?? null,
			'canonical'        => $meta['canonical_url'] ?? null,
		);
	}

	public function update_seo_field( int $post_id, string $field, string $value ): bool {
		$map = array(
			'title'            => 'title',
			'meta_description' => 'description',
			'canonical'        => 'canonical_url',
		);
		if ( ! isset( $map[ $field ] ) ) {
			throw new \Exception( 'Unsupported field for AIOSEO: ' . $field );
		}

		$post_type = get_post_type( $post_id );
		if ( ! $post_type ) {
			throw new \Exception( 'Invalid post.' );
		}
		$rest_base = $this->rest_base_for_post_type( $post_type );

		$request = new \WP_REST_Request( 'PUT', "/wp/v2/{$rest_base}/{$post_id}" );
		$request->set_body_params(
			array(
				'aioseo_meta_data' => array( $map[ $field ] => $value ),
			)
		);
		$response = rest_do_request( $request );

		if ( $response->is_error() ) {
			$error = $response->as_error();
			throw new \Exception( $error ? $error->get_error_message() : 'AIOSEO write failed.' );
		}
		return true;
	}

	private function read_meta_data( int $post_id ): array {
		$post_type = get_post_type( $post_id );
		if ( ! $post_type ) {
			return array();
		}
		$rest_base = $this->rest_base_for_post_type( $post_type );

		$request = new \WP_REST_Request( 'GET', "/wp/v2/{$rest_base}/{$post_id}" );
		$request->set_param( 'context', 'edit' );
		$response = rest_do_request( $request );

		if ( $response->is_error() ) {
			return array();
		}
		$data = $response->get_data();
		return is_array( $data['aioseo_meta_data'] ?? null ) ? $data['aioseo_meta_data'] : array();
	}

	private function rest_base_for_post_type( string $post_type ): string {
		$obj = get_post_type_object( $post_type );
		return ( $obj && ! empty( $obj->rest_base ) ) ? $obj->rest_base : $post_type . 's';
	}
}
