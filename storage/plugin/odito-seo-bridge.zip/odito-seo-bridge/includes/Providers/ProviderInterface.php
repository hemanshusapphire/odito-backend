<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ProviderInterface
 *
 * Every SEO-plugin adapter implements this. Deliberately three operations
 * only — exactly what the Odito backend needs (detect, describe capability,
 * read, write) and nothing more. A provider that cannot safely support a
 * field simply reports write:false for it in get_capabilities() — there is
 * no generic catch-all write path a provider could fall back to.
 */
interface ProviderInterface {

	/**
	 * Stable provider key — matches Odito's own
	 * WordPressConnection.detected_seo_provider enum
	 * (rank_math|yoast|aioseo|seopress).
	 */
	public static function get_key(): string;

	/** True if this provider's plugin is active on this site. */
	public static function is_active(): bool;

	/**
	 * Static capability table, keyed by the ONLY fields the Odito backend's
	 * own Task verification system can currently confirm (title,
	 * meta_description, canonical, robots — see Security::SUPPORTED_FIELDS).
	 * A provider must never report write:true for a field it cannot also
	 * read back afterward — capability here has the same meaning as the
	 * backend's own adapters: "can be safely written AND read back", not
	 * "a write method happens to exist." A provider that has not verified
	 * its storage format for a given field simply omits it (or reports
	 * read:false/write:false) — Rest_Controller::get_capabilities() already
	 * defaults every field a provider's array omits to false/false.
	 *
	 * @return array<string, array{read: bool, write: bool}>
	 */
	public function get_capabilities(): array;

	/**
	 * @param int $post_id
	 * @return array{title: ?string, meta_description: ?string, canonical: ?string, robots: ?string}
	 *   null for any field this provider cannot read — never a fabricated value.
	 *   robots, when supported, is a wire string: "" (no restriction —
	 *   index, follow), "noindex", "nofollow", or "nofollow, noindex"
	 *   (alphabetically sorted — NOT "noindex, nofollow") — see
	 *   Security::VALID_ROBOTS_WIRE_VALUES, which must stay in lockstep with
	 *   this format.
	 */
	public function get_seo_data( int $post_id ): array;

	/**
	 * @param int    $post_id
	 * @param string $field one of: title, meta_description, canonical, robots
	 * @param string $value already sanitized AND shape-validated by the
	 *   caller (Security::validate_field_value) — for robots, always
	 *   already one of Security::VALID_ROBOTS_WIRE_VALUES.
	 * @return bool true on success
	 * @throws \Exception if this field cannot be written for this provider/post
	 */
	public function update_seo_field( int $post_id, string $field, string $value ): bool;
}
