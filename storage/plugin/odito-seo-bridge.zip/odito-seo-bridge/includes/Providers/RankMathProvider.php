<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rank Math has no official REST write path for its own SEO fields — Odito's
 * existing external REST integration confirmed this independently (its
 * Rank Math adapter reports write:false for every field, since the `meta`
 * field on core REST routes only reflects meta explicitly registered for
 * REST, which Rank Math does not do for these keys). This is exactly the
 * gap the Bridge exists to close: running as an in-process WordPress
 * plugin, normal PHP meta access via update_post_meta()/get_post_meta()
 * is unaffected by that REST field-registration restriction — these are
 * Rank Math's own documented internal meta keys.
 */
class RankMathProvider implements ProviderInterface, SiteSchemaProviderInterface {

	const META_TITLE       = 'rank_math_title';
	const META_DESCRIPTION = 'rank_math_description';
	const META_CANONICAL   = 'rank_math_canonical_url';
	// Rank Math's own robots meta box stores selected restrictive directives
	// as a plain array of strings (e.g. array('noindex'), array('noindex',
	// 'nofollow')) — an absent/empty meta value means "use the site-wide
	// default" (normally index, follow). This is Rank Math's documented,
	// stable internal storage key; unlike the schema meta keys this Bridge
	// does NOT yet implement, this format is well-established and has not
	// changed across Rank Math's REST-field-registration history.
	const META_ROBOTS = 'rank_math_robots';

	// Confirmed against Rank Math's own real source
	// (includes/abilities/settings/class-set-website-identity.php and
	// class-set-breadcrumb-settings.php in rankmath/seo-by-rank-math on
	// GitHub) — NOT guessed. Organization/Knowledge Graph fields live in the
	// 'titles' option; the breadcrumbs toggle lives in the 'general' option.
	// Both are plain WordPress options (serialized arrays), never post meta.
	const OPTION_TITLES  = 'rank-math-options-titles';
	const OPTION_GENERAL = 'rank-math-options-general';

	public static function get_key(): string {
		return 'rank_math';
	}

	public static function is_active(): bool {
		return defined( 'RANK_MATH_VERSION' ) || class_exists( '\\RankMath' );
	}

	public function get_capabilities(): array {
		return array(
			'title'            => array(
				'read'  => true,
				'write' => true,
			),
			'meta_description' => array(
				'read'  => true,
				'write' => true,
			),
			'canonical'        => array(
				'read'  => true,
				'write' => true,
			),
			'robots'           => array(
				'read'  => true,
				'write' => true,
			),
		);
	}

	public function get_seo_data( int $post_id ): array {
		return array(
			'title'            => $this->read_meta( $post_id, self::META_TITLE ),
			'meta_description' => $this->read_meta( $post_id, self::META_DESCRIPTION ),
			'canonical'        => $this->read_meta( $post_id, self::META_CANONICAL ),
			'robots'           => $this->read_robots( $post_id ),
		);
	}

	public function update_seo_field( int $post_id, string $field, string $value ): bool {
		if ( 'robots' === $field ) {
			return $this->write_robots( $post_id, $value );
		}
		$map = array(
			'title'            => self::META_TITLE,
			'meta_description' => self::META_DESCRIPTION,
			'canonical'        => self::META_CANONICAL,
		);
		if ( ! isset( $map[ $field ] ) ) {
			throw new \Exception( 'Unsupported field for Rank Math: ' . $field );
		}
		return false !== update_post_meta( $post_id, $map[ $field ], $value );
	}

	private function read_meta( int $post_id, string $key ): ?string {
		$value = get_post_meta( $post_id, $key, true );
		return ( is_string( $value ) && '' !== $value ) ? $value : null;
	}

	/**
	 * Reads rank_math_robots (an array of directive strings, or absent/empty
	 * for "use site default") and reduces it to this Bridge's wire format —
	 * only the restrictive directives it actually contains, comma-space
	 * joined — mirroring valueNormalization.js's robotsValueToWireString()
	 * exactly so the Node backend never has to special-case which provider
	 * produced this string. Always returns a string (never null) — an
	 * absent/malformed meta value is a real, confirmed "no restriction"
	 * state (Rank Math's own default), not an unknown one.
	 */
	private function read_robots( int $post_id ): string {
		$stored = get_post_meta( $post_id, self::META_ROBOTS, true );
		$directives = is_array( $stored ) ? array_values( array_intersect( $stored, array( 'noindex', 'nofollow' ) ) ) : array();
		sort( $directives );
		return implode( ', ', $directives );
	}

	/**
	 * Writes the wire-format robots value (already validated by
	 * Security::validate_field_value to be one of
	 * Security::VALID_ROBOTS_WIRE_VALUES before this is ever reached) back
	 * into rank_math_robots. "" (no restriction) deletes the meta entirely
	 * rather than storing an empty array — matching Rank Math's own editor
	 * behavior when both "noindex" and "nofollow" checkboxes are unchecked,
	 * so the stored state is indistinguishable from a page that never had
	 * custom robots settings applied at all.
	 */
	private function write_robots( int $post_id, string $value ): bool {
		if ( '' === $value ) {
			delete_post_meta( $post_id, self::META_ROBOTS );
			return true;
		}
		$directives = array_map( 'trim', explode( ',', $value ) );
		return false !== update_post_meta( $post_id, self::META_ROBOTS, $directives );
	}

	// ── Site-level schema (Organization/Knowledge Graph, breadcrumbs) ──────
	// Distinct from every method above: these operate on WordPress OPTIONS
	// (site-wide), never on a specific post's meta. Confirmed field-by-field
	// against Rank Math's own real source — see the OPTION_TITLES/
	// OPTION_GENERAL constants' docblock above.

	/**
	 * @return array{organization: array{name: string, description: string, url: string, logo: string, sameAs: string[], protectedSameAs: string[], additionalSameAs: string[]}, breadcrumbs: array{enabled: bool}}
	 */
	public function get_site_schema(): array {
		$titles  = (array) get_option( self::OPTION_TITLES, array() );
		$general = (array) get_option( self::OPTION_GENERAL, array() );

		return array(
			'organization' => array(
				'name'             => (string) ( $titles['knowledgegraph_name'] ?? '' ),
				'description'      => (string) ( $titles['organization_description'] ?? '' ),
				'url'              => (string) ( $titles['url'] ?? '' ),
				'logo'             => (string) ( $titles['knowledgegraph_logo'] ?? '' ),
				// The full, merged list — kept for callers that just want
				// "everything currently in sameAs" without caring about
				// which underlying field each URL came from.
				'sameAs'           => $this->compute_same_as( $titles ),
				// Split out for the frontend's protected-vs-editable
				// display (Section 11): protectedSameAs (Facebook/Twitter,
				// which Odito's write path can NEVER touch) vs
				// additionalSameAs (the social_additional_profiles bucket,
				// the ONLY thing update_same_as() ever modifies).
				'protectedSameAs'  => $this->compute_protected_same_as( $titles ),
				'additionalSameAs' => $this->compute_additional_same_as( $titles ),
			),
			'breadcrumbs'  => array(
				'enabled' => 'on' === ( $general['breadcrumbs'] ?? '' ) || true === ( $general['breadcrumbs'] ?? false ),
			),
		);
	}

	/**
	 * Mirrors Rank Math's own JsonLD::get_social_profiles() exactly (same
	 * three sources, same order) so Odito's read always matches what Rank
	 * Math itself would render into the Organization schema's sameAs array.
	 */
	private function compute_same_as( array $titles ): array {
		return array_values( array_filter( array_merge(
			$this->compute_protected_same_as( $titles ),
			$this->compute_additional_same_as( $titles )
		) ) );
	}

	/** Facebook + Twitter-derived URLs only — never written by update_same_as(). */
	private function compute_protected_same_as( array $titles ): array {
		$profiles = array();
		if ( ! empty( $titles['social_url_facebook'] ) ) {
			$profiles[] = trim( $titles['social_url_facebook'] );
		}
		if ( ! empty( $titles['twitter_author_names'] ) ) {
			$profiles[] = 'https://twitter.com/' . trim( $titles['twitter_author_names'] );
		}
		return array_values( array_filter( $profiles ) );
	}

	/** The social_additional_profiles bucket only — the ONLY thing update_same_as() ever modifies. */
	private function compute_additional_same_as( array $titles ): array {
		if ( empty( $titles['social_additional_profiles'] ) ) {
			return array();
		}
		$additional = preg_split( '/\r\n|\r|\n/', (string) $titles['social_additional_profiles'] );
		return array_values( array_filter( array_map( 'trim', $additional ) ) );
	}

	/**
	 * @param string      $entity 'organization' or 'breadcrumbs'
	 * @param string      $field  one of Security::SITE_SCHEMA_ENTITIES[$entity]
	 * @param string|bool $value  the new value (bool only for breadcrumbs.enabled)
	 * @param string|null $op     'add'|'remove' — REQUIRED for organization.sameAs, ignored otherwise
	 * @throws \Exception on an unsupported field or a sameAs remove for a URL not in Odito's own managed bucket
	 */
	public function update_site_schema_field( string $entity, string $field, $value, ?string $op = null ): bool {
		if ( 'breadcrumbs' === $entity && 'enabled' === $field ) {
			$general               = (array) get_option( self::OPTION_GENERAL, array() );
			$general['breadcrumbs'] = $value ? 'on' : 'off';
			update_option( self::OPTION_GENERAL, $general );
			return true;
		}

		if ( 'organization' === $entity && in_array( $field, array( 'name', 'description', 'url', 'logo' ), true ) ) {
			$map   = array(
				'name'        => 'knowledgegraph_name',
				'description' => 'organization_description',
				'url'         => 'url',
				'logo'        => 'knowledgegraph_logo',
			);
			$titles                 = (array) get_option( self::OPTION_TITLES, array() );
			$titles[ $map[ $field ] ] = (string) $value;
			update_option( self::OPTION_TITLES, $titles );
			return true;
		}

		if ( 'organization' === $entity && 'sameAs' === $field ) {
			return $this->update_same_as( (string) $value, $op );
		}

		throw new \Exception( 'Unsupported site schema field: ' . $entity . '.' . $field );
	}

	/**
	 * Surgical add/remove on ONLY the social_additional_profiles bucket —
	 * social_url_facebook and twitter_author_names (the other two sources
	 * compute_same_as() reads) are NEVER touched by this method, by
	 * construction, so an existing Facebook/Twitter profile can never be
	 * deleted through this capability regardless of what URL is requested
	 * for removal. A remove for a URL that isn't in the additional-profiles
	 * bucket (e.g. it's the Facebook one) is refused rather than silently
	 * doing nothing or reaching into a field this capability doesn't own.
	 */
	private function update_same_as( string $url, ?string $op ): bool {
		$titles       = (array) get_option( self::OPTION_TITLES, array() );
		$raw          = (string) ( $titles['social_additional_profiles'] ?? '' );
		$current      = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ) ) );

		if ( 'add' === $op ) {
			if ( in_array( $url, $this->compute_same_as( $titles ), true ) ) {
				return true; // Already present (anywhere in the full computed list) — idempotent no-op.
			}
			$current[] = $url;
		} elseif ( 'remove' === $op ) {
			$index = array_search( $url, $current, true );
			if ( false === $index ) {
				throw new \Exception( 'This URL is not one Odito can remove (it is not in the additional-profiles list Odito manages).' );
			}
			unset( $current[ $index ] );
			$current = array_values( $current );
		} else {
			throw new \Exception( 'sameAs requires an explicit op of "add" or "remove".' );
		}

		$titles['social_additional_profiles'] = implode( "\n", $current );
		update_option( self::OPTION_TITLES, $titles );
		return true;
	}
}
