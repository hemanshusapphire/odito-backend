<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SEOPress stores its title/description as standard post meta under its
 * own documented key convention (the same keys SEOPress's own REST
 * `title-description-metas` endpoint reads/writes). Direct
 * get_post_meta()/update_post_meta() is used rather than SEOPress's
 * internal REST controller class, to avoid depending on an internal class
 * name/signature that isn't part of SEOPress's stable public contract.
 *
 * Canonical is intentionally left unsupported: SEOPress's canonical
 * override lives under its robots-settings meta group, a mapping this
 * plugin has not independently confirmed against a live install to the
 * same confidence as title/description. Per the "do not overclaim" rule,
 * it stays read:false/write:false until verified.
 */
class SeopressProvider implements ProviderInterface {

	const META_TITLE       = '_seopress_titles_title';
	const META_DESCRIPTION = '_seopress_titles_desc';

	public static function get_key(): string {
		return 'seopress';
	}

	public static function is_active(): bool {
		return defined( 'SEOPRESS_VERSION' ) || function_exists( 'seopress_get_service' );
	}

	public function get_capabilities(): array {
		return array(
			'title'            => array(
				'read'  => true,
				'write' => true,
			),
			'meta_description' => array(
				'read'  => true,
				'write' => true,
			),
			'canonical'        => array(
				'read'  => false,
				'write' => false,
			),
		);
	}

	public function get_seo_data( int $post_id ): array {
		return array(
			'title'            => $this->read_meta( $post_id, self::META_TITLE ),
			'meta_description' => $this->read_meta( $post_id, self::META_DESCRIPTION ),
			'canonical'        => null,
		);
	}

	public function update_seo_field( int $post_id, string $field, string $value ): bool {
		$map = array(
			'title'            => self::META_TITLE,
			'meta_description' => self::META_DESCRIPTION,
		);
		if ( ! isset( $map[ $field ] ) ) {
			throw new \Exception( 'Unsupported field for SEOPress: ' . $field );
		}
		return false !== update_post_meta( $post_id, $map[ $field ], $value );
	}

	private function read_meta( int $post_id, string $key ): ?string {
		$value = get_post_meta( $post_id, $key, true );
		return ( is_string( $value ) && '' !== $value ) ? $value : null;
	}
}
