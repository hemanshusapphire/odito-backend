<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detects which supported SEO plugin(s) are active and resolves the single
 * provider to use — mirroring the Odito backend's own
 * getAdapterForConnection() "never silently choose one" rule: if more than
 * one supported plugin is simultaneously active, this reports 'multiple'
 * and refuses to hand back a usable provider, rather than guessing which
 * one the site actually intends to use for SEO output.
 */
class ProviderRegistry {

	const PROVIDER_CLASSES = array(
		AioseoProvider::class,
		SeopressProvider::class,
		RankMathProvider::class,
		YoastProvider::class,
	);

	/** @return string[] every supported provider key currently active. */
	public static function detect_active_providers(): array {
		$active = array();
		foreach ( self::PROVIDER_CLASSES as $class ) {
			if ( $class::is_active() ) {
				$active[] = $class::get_key();
			}
		}
		return $active;
	}

	/**
	 * @return array{provider: string, providers: string[]}
	 *   'none' if nothing supported is active; 'multiple' (with every match
	 *   listed) if more than one is — never a silently-picked single value
	 *   in that case.
	 */
	public static function resolve(): array {
		$active = self::detect_active_providers();
		if ( 0 === count( $active ) ) {
			return array(
				'provider'  => 'none',
				'providers' => array(),
			);
		}
		if ( count( $active ) > 1 ) {
			return array(
				'provider'  => 'multiple',
				'providers' => $active,
			);
		}
		return array(
			'provider'  => $active[0],
			'providers' => $active,
		);
	}

	/** @return ProviderInterface|null null when ambiguous or none active. */
	public static function get_active_provider_instance(): ?ProviderInterface {
		$resolved = self::resolve();
		if ( 'none' === $resolved['provider'] || 'multiple' === $resolved['provider'] ) {
			return null;
		}
		foreach ( self::PROVIDER_CLASSES as $class ) {
			if ( $class::get_key() === $resolved['provider'] ) {
				return new $class();
			}
		}
		return null;
	}
}
