<?php
namespace Odito\SeoBridge;

use Odito\SeoBridge\Providers\ProviderRegistry;
use Odito\SeoBridge\Providers\SiteSchemaProviderInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles the routes Odito's backend talks to:
 *   GET  /odito/v1/status
 *   GET  /odito/v1/capabilities
 *   GET  /odito/v1/seo/{postId}
 *   PUT  /odito/v1/seo/{postId}
 *   GET  /odito/v1/seo/site
 *   PUT  /odito/v1/seo/site
 *   GET  /odito/v1/faq-schema/{postId}
 *   PUT  /odito/v1/faq-schema/{postId}
 *   GET  /odito/v1/rating-schema/{postId}
 *   PUT  /odito/v1/rating-schema/{postId}
 *
 * Every per-post write goes through the exact same validation regardless of
 * which provider is active: field must be in Security::SUPPORTED_FIELDS,
 * post must exist and be a public type, the current authenticated user must
 * be able to edit that specific post, the active provider must not be
 * ambiguous ('multiple'), and the resolved provider must itself report
 * write:true for that field. No route ever accepts a provider name, meta
 * key, or arbitrary post type from the request — those are always derived
 * server-side from ProviderRegistry / get_post_type().
 *
 * The /seo/site routes are SITE-LEVEL (Organization/Knowledge Graph,
 * breadcrumbs) — gated behind manage_options rather than edit_post (see
 * Security::current_user_can_manage_site_seo), since these affect every
 * page on the site, not one post. Only providers implementing the optional
 * SiteSchemaProviderInterface support them; every other provider
 * (including Rank Math's own legacy state before this capability existed)
 * gets a clean 'not supported' response rather than a fatal error.
 *
 * The /faq-schema/{postId} routes are per-post like /seo/{postId} (same
 * edit_post permission check) but are independent of the active SEO provider:
 * see Faq_Schema. They accept a FAQPage JSON-LD object, validate it strictly,
 * and store only its Question/Answer pairs.
 */
class Rest_Controller {

	const NAMESPACE_ = 'odito/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_status' ),
				'permission_callback' => array( __CLASS__, 'permission_authenticated' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/capabilities',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_capabilities' ),
				'permission_callback' => array( __CLASS__, 'permission_authenticated' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/seo/(?P<postId>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_seo_data' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update_seo_data' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/seo/site',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_site_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_site_seo' ),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update_site_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_manage_site_seo' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/rating-schema/(?P<postId>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_rating_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update_rating_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_,
			'/faq-schema/(?P<postId>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_faq_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => array( __CLASS__, 'update_faq_schema' ),
					'permission_callback' => array( __CLASS__, 'permission_can_edit_post' ),
					'args'                => self::post_id_args(),
				),
			)
		);
	}

	private static function post_id_args(): array {
		return array(
			'postId' => array(
				'required'          => true,
				'validate_callback' => function ( $value ) {
					return is_numeric( $value ) && (int) $value > 0;
				},
			),
		);
	}

	// ── Permission callbacks ────────────────────────────────────────────

	/** Any authenticated user — status/capabilities reveal no post-specific data. */
	public static function permission_authenticated() {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'odito_not_authenticated', 'Authentication is required.', array( 'status' => 401 ) );
		}
		return true;
	}

	/**
	 * Real capability check on the SPECIFIC post — never a blanket role
	 * check. Returns a WP_Error with a clear reason rather than a bare
	 * false.
	 */
	public static function permission_can_edit_post( \WP_REST_Request $request ) {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'odito_not_authenticated', 'Authentication is required.', array( 'status' => 401 ) );
		}
		$post_id = (int) $request->get_param( 'postId' );
		$post    = Security::validate_post( $post_id );
		if ( ! $post ) {
			return new \WP_Error( 'odito_invalid_post', 'This post could not be found or is not a supported content type.', array( 'status' => 404 ) );
		}
		if ( ! Security::current_user_can_edit_post( $post_id ) ) {
			return new \WP_Error( 'odito_permission_denied', 'You do not have permission to edit this post.', array( 'status' => 403 ) );
		}
		return true;
	}

	/** Site-level schema changes require manage_options (Administrator), regardless of which post/page the fix originated from. */
	public static function permission_manage_site_seo() {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'odito_not_authenticated', 'Authentication is required.', array( 'status' => 401 ) );
		}
		if ( ! Security::current_user_can_manage_site_seo() ) {
			return new \WP_Error( 'odito_permission_denied', 'You do not have permission to change site-wide SEO settings.', array( 'status' => 403 ) );
		}
		return true;
	}

	// ── Route handlers ───────────────────────────────────────────────────

	public static function get_status(): \WP_REST_Response {
		$resolved = ProviderRegistry::resolve();
		global $wp_version;

		$provider    = 'multiple' !== $resolved['provider'] ? ProviderRegistry::get_active_provider_instance() : null;
		$site_schema = $provider instanceof SiteSchemaProviderInterface;

		return new \WP_REST_Response(
			array(
				'installed'         => true,
				'bridge_version'    => ODITO_SEO_BRIDGE_VERSION,
				'provider'          => $resolved['provider'],
				'providers'         => $resolved['providers'],
				'wordpress_version' => $wp_version,
				'supports'          => array(
					'read'         => true,
					'write'        => 'multiple' !== $resolved['provider'],
					'site_schema'  => $site_schema,
					// Independent of the active SEO provider — the Bridge renders FAQ JSON-LD itself.
					'faq_schema'   => true,
					'rating_schema' => true,
				),
			),
			200
		);
	}

	public static function get_capabilities(): \WP_REST_Response {
		$resolved = ProviderRegistry::resolve();

		$fields = array();
		foreach ( Security::SUPPORTED_FIELDS as $field ) {
			$fields[ $field ] = array(
				'read'  => false,
				'write' => false,
			);
		}

		if ( 'multiple' !== $resolved['provider'] ) {
			$provider = ProviderRegistry::get_active_provider_instance();
			if ( $provider ) {
				$provider_caps = $provider->get_capabilities();
				foreach ( Security::SUPPORTED_FIELDS as $field ) {
					if ( isset( $provider_caps[ $field ] ) ) {
						$fields[ $field ] = array(
							'read'  => (bool) ( $provider_caps[ $field ]['read'] ?? false ),
							'write' => (bool) ( $provider_caps[ $field ]['write'] ?? false ),
						);
					}
				}
			}
		}

		return new \WP_REST_Response(
			array(
				'provider'  => $resolved['provider'],
				'providers' => $resolved['providers'],
				'fields'    => $fields,
			),
			200
		);
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function get_seo_data( \WP_REST_Request $request ) {
		$post_id  = (int) $request->get_param( 'postId' );
		$resolved = ProviderRegistry::resolve();

		if ( 'multiple' === $resolved['provider'] ) {
			return new \WP_Error( 'odito_multiple_providers', 'Multiple supported SEO plugins are active — resolve the ambiguity before reading SEO data.', array( 'status' => 409 ) );
		}

		$provider = ProviderRegistry::get_active_provider_instance();
		$data     = $provider
			? $provider->get_seo_data( $post_id )
			: array(
				'title'            => null,
				'meta_description' => null,
				'canonical'        => null,
				'robots'           => null,
			);

		return new \WP_REST_Response(
			array(
				'postId'   => $post_id,
				'provider' => $resolved['provider'],
				'fields'   => $data,
			),
			200
		);
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function update_seo_data( \WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'postId' );
		$field   = $request->get_param( 'field' );
		$value   = $request->get_param( 'value' );

		if ( ! is_string( $field ) || ! Security::is_supported_field( $field ) ) {
			return new \WP_Error( 'odito_field_unsupported', 'This field is not supported by the Odito SEO Bridge.', array( 'status' => 422 ) );
		}
		if ( ! is_string( $value ) ) {
			return new \WP_Error( 'odito_invalid_value', 'A string value is required.', array( 'status' => 400 ) );
		}
		// Reasonable upper bound — mirrors the Odito backend's own
		// expectedCurrentValue length cap; no legitimate SEO field needs more.
		if ( strlen( $value ) > 5000 ) {
			return new \WP_Error( 'odito_invalid_value', 'This value is too long.', array( 'status' => 400 ) );
		}
		$value = sanitize_text_field( $value );

		// Defense-in-depth: reject a malformed canonical/robots value here
		// too, even though the Node backend already validates before ever
		// sending this request — this route must never trust shape purely
		// from an authenticated caller.
		$value_check = Security::validate_field_value( $field, $value );
		if ( true !== $value_check ) {
			return new \WP_Error( 'odito_invalid_value', $value_check, array( 'status' => 400 ) );
		}

		$resolved = ProviderRegistry::resolve();
		if ( 'multiple' === $resolved['provider'] ) {
			return new \WP_Error( 'odito_multiple_providers', 'Multiple supported SEO plugins are active — resolve the ambiguity before applying a fix.', array( 'status' => 409 ) );
		}
		if ( 'none' === $resolved['provider'] ) {
			return new \WP_Error( 'odito_provider_not_detected', 'No supported SEO plugin is active on this site.', array( 'status' => 422 ) );
		}

		$provider     = ProviderRegistry::get_active_provider_instance();
		$capabilities = $provider->get_capabilities();
		if ( empty( $capabilities[ $field ]['write'] ) ) {
			return new \WP_Error( 'odito_field_unsupported', 'This field is not writable for the active SEO plugin.', array( 'status' => 422 ) );
		}

		try {
			$provider->update_seo_field( $post_id, $field, $value );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'odito_write_failed', 'Failed to write this change.', array( 'status' => 500 ) );
		}

		$data = $provider->get_seo_data( $post_id );

		return new \WP_REST_Response(
			array(
				'postId'   => $post_id,
				'provider' => $resolved['provider'],
				'field'    => $field,
				'value'    => $data[ $field ] ?? null,
			),
			200
		);
	}

	/** @return \WP_REST_Response */
	public static function get_rating_schema( \WP_REST_Request $request ) {
		return self::rating_schema_response( (int) $request->get_param( 'postId' ) );
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function update_rating_schema( \WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'postId' );

		// Strict, all-or-nothing: only a well-formed AggregateRating on an entity with an
		// absolute @id and a name is ever stored. What is stored is the validated
		// target + rating, never the raw request.
		$stored = Rating_Schema::validate( $request->get_param( 'schema' ) );
		if ( null === $stored ) {
			return new \WP_Error( 'odito_invalid_value', 'A valid AggregateRating is required: the entity needs an absolute @id, a @type and a name, and the rating needs a ratingValue inside its scale plus a reviewCount or ratingCount.', array( 'status' => 400 ) );
		}

		try {
			Rating_Schema::save( $post_id, $stored );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'odito_write_failed', 'Failed to write this change.', array( 'status' => 500 ) );
		}

		return self::rating_schema_response( $post_id );
	}

	/** Always answers with what is now actually stored (re-read), never an echo of the request. */
	private static function rating_schema_response( int $post_id ): \WP_REST_Response {
		$stored = Rating_Schema::get( $post_id );
		return new \WP_REST_Response(
			array(
				'postId' => $post_id,
				'exists' => null !== $stored,
				'schema' => null === $stored ? null : Rating_Schema::build_node( $stored ),
			),
			200
		);
	}

	/** @return \WP_REST_Response */
	public static function get_faq_schema( \WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'postId' );
		return self::faq_schema_response( $post_id );
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function update_faq_schema( \WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'postId' );
		$schema  = $request->get_param( 'schema' );

		// Strict, all-or-nothing validation: only a well-formed FAQPage whose every
		// entry is a Question with an accepted-answer text is ever stored.
		$pairs = Faq_Schema::pairs_from_schema( $schema );
		if ( null === $pairs ) {
			return new \WP_Error( 'odito_invalid_value', 'A valid FAQPage schema is required: every entry must be a Question with a non-empty name and acceptedAnswer text, and there must be between 1 and ' . Faq_Schema::MAX_PAIRS . ' entries.', array( 'status' => 400 ) );
		}

		try {
			Faq_Schema::save_pairs( $post_id, $pairs );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'odito_write_failed', 'Failed to write this change.', array( 'status' => 500 ) );
		}

		return self::faq_schema_response( $post_id );
	}

	/** Always answers with what is now actually stored (re-read), never an echo of the request. */
	private static function faq_schema_response( int $post_id ): \WP_REST_Response {
		$pairs = Faq_Schema::get_pairs( $post_id );
		return new \WP_REST_Response(
			array(
				'postId' => $post_id,
				'exists' => ! empty( $pairs ),
				'schema' => empty( $pairs ) ? null : Faq_Schema::build_schema( $pairs ),
			),
			200
		);
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function get_site_schema() {
		$resolved = ProviderRegistry::resolve();
		if ( 'multiple' === $resolved['provider'] ) {
			return new \WP_Error( 'odito_multiple_providers', 'Multiple supported SEO plugins are active — resolve the ambiguity before reading site schema.', array( 'status' => 409 ) );
		}

		$provider = ProviderRegistry::get_active_provider_instance();
		if ( ! $provider instanceof SiteSchemaProviderInterface ) {
			return new \WP_Error( 'odito_site_schema_unsupported', 'Site-level schema is not supported for the active SEO plugin.', array( 'status' => 422 ) );
		}

		return new \WP_REST_Response(
			array(
				'provider' => $resolved['provider'],
			) + $provider->get_site_schema(),
			200
		);
	}

	/** @return \WP_REST_Response|\WP_Error */
	public static function update_site_schema( \WP_REST_Request $request ) {
		$entity = $request->get_param( 'entity' );
		$field  = $request->get_param( 'field' );
		$value  = $request->get_param( 'value' );
		$op     = $request->get_param( 'op' );

		if ( ! is_string( $entity ) || ! is_string( $field ) || ! Security::is_supported_site_field( $entity, $field ) ) {
			return new \WP_Error( 'odito_field_unsupported', 'This site schema field is not supported by the Odito SEO Bridge.', array( 'status' => 422 ) );
		}

		if ( 'breadcrumbs' === $entity ) {
			if ( ! is_bool( $value ) ) {
				return new \WP_Error( 'odito_invalid_value', 'A boolean value is required.', array( 'status' => 400 ) );
			}
		} else {
			if ( ! is_string( $value ) || '' === trim( $value ) ) {
				return new \WP_Error( 'odito_invalid_value', 'A non-empty string value is required.', array( 'status' => 400 ) );
			}
			if ( strlen( $value ) > 5000 ) {
				return new \WP_Error( 'odito_invalid_value', 'This value is too long.', array( 'status' => 400 ) );
			}
			$value = sanitize_text_field( $value );

			$value_check = Security::validate_site_field_value( $entity, $field, $value );
			if ( true !== $value_check ) {
				return new \WP_Error( 'odito_invalid_value', $value_check, array( 'status' => 400 ) );
			}
		}

		if ( 'sameAs' === $field && ! in_array( $op, array( 'add', 'remove' ), true ) ) {
			return new \WP_Error( 'odito_invalid_value', 'sameAs requires "op" to be "add" or "remove".', array( 'status' => 400 ) );
		}

		$resolved = ProviderRegistry::resolve();
		if ( 'multiple' === $resolved['provider'] ) {
			return new \WP_Error( 'odito_multiple_providers', 'Multiple supported SEO plugins are active — resolve the ambiguity before applying a fix.', array( 'status' => 409 ) );
		}

		$provider = ProviderRegistry::get_active_provider_instance();
		if ( ! $provider instanceof SiteSchemaProviderInterface ) {
			return new \WP_Error( 'odito_site_schema_unsupported', 'Site-level schema is not supported for the active SEO plugin.', array( 'status' => 422 ) );
		}

		try {
			$provider->update_site_schema_field( $entity, $field, $value, $op );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'odito_write_failed', $e->getMessage(), array( 'status' => 500 ) );
		}

		return new \WP_REST_Response(
			array(
				'provider' => $resolved['provider'],
			) + $provider->get_site_schema(),
			200
		);
	}
}
