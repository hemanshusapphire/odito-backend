<?php
namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * FAQPage structured data for a single post, applied on Odito's behalf.
 *
 * Deliberately independent of every SEO plugin: it neither reads nor writes
 * any SEO plugin's data, and it never edits post content. The Bridge keeps the
 * FAQ's question/answer pairs in ONE post-meta key of its own and prints the
 * matching FAQPage JSON-LD in <head> itself. That is what makes it work on a
 * site with Rank Math, Yoast, several of them, or none.
 *
 * What is stored is not the request payload but the validated Question/Answer
 * pairs extracted from it — the JSON-LD that is rendered is always rebuilt from
 * those pairs, so nothing else a caller sends can ever reach the page.
 * Validation is strict and all-or-nothing: if any entry is malformed the whole
 * schema is rejected, never partially saved.
 */
class Faq_Schema {

	/** The only post-meta key this feature writes. Underscore prefix keeps it out of the Custom Fields UI. */
	const META_KEY = '_odito_faq_pairs';

	const MAX_PAIRS           = 50;
	const MAX_QUESTION_LENGTH = 500;
	const MAX_ANSWER_LENGTH   = 10000;

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'render' ), 30 );
	}

	/**
	 * Validates a FAQPage JSON-LD structure and returns its pairs.
	 *
	 * @param mixed $schema Decoded JSON (array) as received from the REST request.
	 * @return array|null List of array{question:string,answer:string}, or null if the schema is not a well-formed FAQPage.
	 */
	public static function pairs_from_schema( $schema ) {
		if ( ! is_array( $schema ) ) {
			return null;
		}

		$type = isset( $schema['@type'] ) ? $schema['@type'] : null;
		$is_faq_page = ( 'FAQPage' === $type ) || ( is_array( $type ) && in_array( 'FAQPage', $type, true ) );
		if ( ! $is_faq_page ) {
			return null;
		}

		$entities = isset( $schema['mainEntity'] ) ? $schema['mainEntity'] : null;
		if ( ! is_array( $entities ) || empty( $entities ) || count( $entities ) > self::MAX_PAIRS ) {
			return null;
		}

		$pairs = array();
		$seen  = array();
		foreach ( $entities as $entity ) {
			if ( ! is_array( $entity ) || ! isset( $entity['@type'] ) || 'Question' !== $entity['@type'] ) {
				return null;
			}
			if ( ! isset( $entity['name'] ) || ! is_string( $entity['name'] ) ) {
				return null;
			}
			$answer = isset( $entity['acceptedAnswer'] ) ? $entity['acceptedAnswer'] : null;
			if ( ! is_array( $answer ) || ! isset( $answer['text'] ) || ! is_string( $answer['text'] ) ) {
				return null;
			}

			$question = self::clean_text( $entity['name'] );
			$text     = self::clean_text( $answer['text'] );
			if ( '' === $question || '' === $text ) {
				return null;
			}
			if ( mb_strlen( $question, 'UTF-8' ) > self::MAX_QUESTION_LENGTH || mb_strlen( $text, 'UTF-8' ) > self::MAX_ANSWER_LENGTH ) {
				return null;
			}

			// mb_strlen() is polyfilled by WordPress core, mb_strtolower() is not — don't fatal on hosts without mbstring.
			$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( $question, 'UTF-8' ) : strtolower( $question );
			if ( isset( $seen[ $key ] ) ) {
				return null;
			}
			$seen[ $key ] = true;

			$pairs[] = array(
				'question' => $question,
				'answer'   => $text,
			);
		}

		return $pairs;
	}

	/**
	 * Whitespace-collapse only. The text is what the visitor sees on the page,
	 * so it is neither reworded nor stripped of tag-like characters here (JSON
	 * encoding on output takes care of making it safe inside <script>).
	 */
	private static function clean_text( $value ) {
		$value = wp_check_invalid_utf8( (string) $value, true );
		$value = preg_replace( '/\s+/u', ' ', $value );
		return trim( (string) $value );
	}

	/** @return array List of array{question:string,answer:string}; empty if nothing is stored. */
	public static function get_pairs( int $post_id ): array {
		$raw = get_post_meta( $post_id, self::META_KEY, true );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}
		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}
		// Re-validate on read so a hand-edited/corrupt meta value can never be rendered.
		$pairs = self::pairs_from_schema( self::build_schema( $decoded ) );
		return null === $pairs ? array() : $pairs;
	}

	/** Stores pairs that already passed pairs_from_schema(). */
	public static function save_pairs( int $post_id, array $pairs ) {
		// update_post_meta() expects slashed data (it unslashes before saving).
		update_post_meta( $post_id, self::META_KEY, wp_slash( wp_json_encode( $pairs, JSON_UNESCAPED_UNICODE ) ) );
	}

	/** Builds the FAQPage JSON-LD array from pairs — the only source of what gets rendered or returned. */
	public static function build_schema( array $pairs ): array {
		$entities = array();
		foreach ( $pairs as $pair ) {
			if ( ! isset( $pair['question'], $pair['answer'] ) ) {
				continue;
			}
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $pair['question'],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $pair['answer'],
				),
			);
		}
		return array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);
	}

	/** wp_head: prints the stored FAQPage JSON-LD for the current singular post. */
	public static function render() {
		if ( ! is_singular() ) {
			return;
		}
		$post = get_queried_object();
		if ( ! $post || empty( $post->ID ) ) {
			return;
		}

		$pairs = self::get_pairs( (int) $post->ID );
		if ( empty( $pairs ) ) {
			return;
		}

		// Never emit a second FAQPage when the post already carries one authored
		// through an SEO plugin's FAQ block — duplicate FAQPage markup is invalid.
		if ( has_block( 'rank-math/faq-block', $post ) || has_block( 'yoast/faq-block', $post ) ) {
			return;
		}

		/**
		 * Lets a site opt a post out of the Odito-rendered FAQ schema (e.g. another
		 * plugin already prints FAQPage for it).
		 *
		 * @param bool    $render Whether to render. Default true.
		 * @param WP_Post $post   The current post.
		 */
		if ( ! apply_filters( 'odito_seo_bridge_render_faq_schema', true, $post ) ) {
			return;
		}

		// JSON_HEX_TAG/AMP: "<", ">" and "&" are escaped, so answer text can never close the <script> element.
		$json = wp_json_encode( self::build_schema( $pairs ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
		if ( ! is_string( $json ) || '' === $json ) {
			return;
		}

		echo "\n<script type=\"application/ld+json\" class=\"odito-faq-schema\">" . $json . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with HEX_TAG/HEX_AMP above.
	}
}
