=== Odito SEO Bridge ===
Contributors: odito
Tags: seo, rank math, yoast, seopress, aioseo, api
Requires at least: 5.6
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lets Odito read and apply on-page SEO fixes through whichever supported SEO plugin is active on your site.

== Description ==

Odito audits your site's SEO and AI-visibility, and can apply certain fixes
directly — title tags, meta descriptions, canonical URLs, and robots meta
(index/noindex, follow/nofollow) on a per-page basis, plus (Rank Math only,
currently) site-wide fixes: adding a social profile URL to your
Organization schema's sameAs property, and enabling breadcrumb structured
data. WordPress's own REST API does not expose write access to these
fields for most SEO plugins (Rank Math and Yoast SEO in particular
register no writable REST field for them at all). This plugin closes that
gap: running as ordinary WordPress PHP code, it can safely read and write
these fields using each SEO plugin's own documented storage mechanism.

Supported SEO plugins:

* All in One SEO (AIOSEO)
* SEOPress
* Rank Math SEO
* Yoast SEO

If more than one supported SEO plugin is active at the same time, the
Bridge refuses to guess which one to use — it reports the ambiguity to
Odito rather than writing to the wrong plugin's fields.

FAQ structured data: when a page already shows an FAQ but has no FAQPage
schema, Odito can apply FAQPage JSON-LD built from that page's own visible
questions and answers. This works with any SEO plugin, or none. The Bridge
keeps the question/answer pairs in one post-meta key of its own
(`_odito_faq_pairs`) and prints the JSON-LD in the page's <head>; it never edits
your post content or any SEO plugin's data. If the post already contains a
Rank Math or Yoast FAQ block the Bridge prints nothing, so FAQPage markup is
never duplicated. Sites can also opt a post out with the
`odito_seo_bridge_render_faq_schema` filter.

AggregateRating structured data: when a page displays a rating and review
count but has no AggregateRating markup, Odito can apply the rating shown on
the page to an entity that already exists in the page's own schema (a Product,
Service, LocalBusiness or Organization). The rating is merged into that entity
by its @id — inside Rank Math's or Yoast SEO's own JSON-LD where they expose it,
otherwise as a node carrying that same @id — never as an unrelated new entity.
The validated target and rating are kept in one post-meta key of the Bridge's own
(`_odito_aggregate_rating`). Sites can opt a post out with the
`odito_seo_bridge_render_rating_schema` filter.

This plugin does not store any credentials. Authentication happens through
a standard WordPress Application Password that you generate for your own
account and provide to Odito directly — this plugin only enforces that the
authenticated user has permission to edit the specific post being changed.

This plugin is independent of, and does not interact with, the separate
Odito Lead Capture plugin.

== Installation ==

1. Upload the `odito-seo-bridge` folder to `/wp-content/plugins/`, or
   install the zip through Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Make sure exactly one of the supported SEO plugins (AIOSEO, SEOPress,
   Rank Math, or Yoast SEO) is active.
4. In your WordPress profile, create an Application Password and provide
   it to Odito when connecting your site.

== Frequently Asked Questions ==

= Does this plugin work without an SEO plugin installed? =

The Bridge itself will report that no supported provider is active, and
Odito will fall back to whatever it can already read/write through core
WordPress fields.

= What happens if I have two SEO plugins active? =

The Bridge reports this as an ambiguous state and will not read or write
SEO fields until only one supported plugin is active.

== Changelog ==

= 1.3.1 =
* Hardening: URLs written to site-level schema (Organization sameAs, url, logo) and to the
  canonical field are now rejected if they contain whitespace, line breaks, control
  characters, quotes, or backslashes. Rank Math stores additional social profiles one per
  line, so a URL containing a line break could otherwise have added an unintended extra profile.
* No new capabilities and no REST changes; sites already on 1.3.0 keep every capability.

= 1.3.0 =
* Added per-page AggregateRating structured data (GET/PUT
  /odito/v1/rating-schema/{postId}, same edit_post gate as the other per-post
  routes). Validated strictly (entity with absolute @id + @type + name; rating
  inside its scale with a review or rating count); only the validated
  target and rating are stored and everything printed is rebuilt from them.
* Merges into the matching entity of Rank Math (`rank_math/json_ld`) or Yoast
  SEO (`wpseo_schema_graph`) when present; otherwise prints a node with the
  same @id.
* /status now reports supports.rating_schema. It does not depend on the active
  SEO plugin.
* The plugin now also owns the post-meta key `_odito_aggregate_rating`,
  removed on uninstall.

= 1.2.0 =
* Added per-page FAQPage structured data (GET/PUT /odito/v1/faq-schema/{postId},
  gated by the same edit_post check as the other per-post routes). The
  request is validated strictly (a FAQPage whose every entry is a Question
  with a non-empty name and accepted-answer text, at most 50 entries); only
  the validated question/answer pairs are stored, and the JSON-LD that is
  printed is always rebuilt from them.
* /status now reports supports.faq_schema so older Bridge versions are never
  assumed to have this capability. It does not depend on the active SEO plugin.
* The plugin now owns one post-meta key (`_odito_faq_pairs`), which is removed
  when the plugin is uninstalled.

= 1.1.0 =
* Added robots meta (index/noindex, follow/nofollow) support — Rank Math only.
* Added site-level schema support (Rank Math only): adding a social profile
  URL to Organization sameAs (never overwrites Facebook/Twitter-derived
  profiles), and enabling breadcrumb structured data.
* New site-level REST routes (GET/PUT /odito/v1/seo/site), gated behind
  manage_options rather than the per-post edit_post check.
* /status now reports supports.site_schema so older Bridge versions are
  never assumed to have this capability.

= 1.0.0 =
* Initial release. Supports AIOSEO, SEOPress, Rank Math, and Yoast SEO for
  title, meta description, and canonical URL.
