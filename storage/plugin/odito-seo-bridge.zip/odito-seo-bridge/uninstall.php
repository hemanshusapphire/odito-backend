<?php
/**
 * SEO field values written through this plugin live in the meta keys owned by
 * the active SEO plugin (Rank Math / Yoast / SEOPress / AIOSEO's own table),
 * which must be left untouched on uninstall.
 *
 * The things this plugin owns itself are the per-post structured data it renders:
 * FAQ pairs (_odito_faq_pairs, includes/class-faq-schema.php) and AggregateRating
 * (_odito_aggregate_rating, includes/class-rating-schema.php). Both are removed
 * here so no orphaned structured-data settings are left behind.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_post_meta_by_key( '_odito_faq_pairs' );
delete_post_meta_by_key( '_odito_aggregate_rating' );
