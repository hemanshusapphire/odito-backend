<?php
/**
 * Plugin Name:       Odito SEO Bridge
 * Plugin URI:        https://oditoai.com
 * Description:       Lets Odito read and apply on-page SEO fixes through whichever supported SEO plugin (All in One SEO, SEOPress, Rank Math, or Yoast SEO) is active on this site: title, meta description and canonical URL, plus robots meta (Rank Math). Also applies site-level Rank Math schema fixes (Organization sameAs, breadcrumbs), per-page FAQPage structured data built from a page's own visible FAQ, and AggregateRating attached to a page's existing schema entity. Requires an active WordPress connection (Application Password) from your Odito dashboard — this plugin stores no credentials of its own.
 * Version:           1.3.1
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Odito
 * Author URI:        https://oditoai.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       odito-seo-bridge
 *
 * Every class here lives under the Odito\SeoBridge namespace. This plugin
 * is entirely separate from, and never touches, the unrelated Odito Lead
 * Capture plugin (odito-wordpress-plugin) — different purpose, different
 * trust boundary, no shared code or state.
 */

namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin header's `Version:` line above is the ONE place the version is
 * written. WordPress displays and compares that value when deciding whether an
 * upload is an update, so the version this plugin reports to Odito
 * (/odito/v1/status -> bridge_version) is read from it rather than repeated as
 * a second literal that could silently disagree.
 */
function odito_seo_bridge_read_version(): string {
	$data = get_file_data( __FILE__, array( 'Version' => 'Version' ), 'plugin' );
	return '' !== $data['Version'] ? $data['Version'] : '0.0.0';
}

define( 'ODITO_SEO_BRIDGE_VERSION', odito_seo_bridge_read_version() );
define( 'ODITO_SEO_BRIDGE_MIN_WP', '5.6' );
define( 'ODITO_SEO_BRIDGE_DIR', plugin_dir_path( __FILE__ ) );

function odito_seo_bridge_wp_version_ok(): bool {
	global $wp_version;
	return version_compare( $wp_version, ODITO_SEO_BRIDGE_MIN_WP, '>=' );
}

function odito_seo_bridge_admin_notice_unsupported_wp() {
	echo '<div class="notice notice-error"><p>' .
		esc_html__( 'Odito SEO Bridge requires WordPress 5.6 or newer and has been disabled.', 'odito-seo-bridge' ) .
		'</p></div>';
}

function odito_seo_bridge_bootstrap() {
	if ( ! odito_seo_bridge_wp_version_ok() ) {
		add_action( 'admin_notices', __NAMESPACE__ . '\\odito_seo_bridge_admin_notice_unsupported_wp' );
		return;
	}

	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/ProviderInterface.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/SiteSchemaProviderInterface.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/AioseoProvider.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/SeopressProvider.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/RankMathProvider.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/YoastProvider.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/Providers/ProviderRegistry.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/class-security.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/class-faq-schema.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/class-rating-schema.php';
	require_once ODITO_SEO_BRIDGE_DIR . 'includes/class-rest-controller.php';

	Rest_Controller::init();
	Faq_Schema::init();
	Rating_Schema::init();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\\odito_seo_bridge_bootstrap' );
